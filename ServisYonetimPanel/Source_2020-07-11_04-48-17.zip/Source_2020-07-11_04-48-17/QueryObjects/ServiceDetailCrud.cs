namespace Syp.Business.QueryObjects
{
    /* Query Object Class ServiceDetailCrud */
    internal class ServiceDetailCrud
    {
    }
}