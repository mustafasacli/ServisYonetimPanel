namespace Syp.Business.QueryObjects
{
    /* Query Object Class ServiceCrud */
    internal class ServiceCrud
    {
    }
}