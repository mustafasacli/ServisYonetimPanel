namespace Syp.Business.QueryObjects
{
    /* Query Object Class ServiceDetailTypeCrud */
    internal class ServiceDetailTypeCrud
    {
    }
}