namespace Syp.Business.QueryObjects
{
    /* Query Object Class ServiceUserCrud */
    internal class ServiceUserCrud
    {
    }
}