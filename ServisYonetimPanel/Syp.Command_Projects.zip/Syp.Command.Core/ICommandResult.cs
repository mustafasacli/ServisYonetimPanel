﻿namespace Syp.Command.Core
{
    public interface ICommandResult
    {
    }
}