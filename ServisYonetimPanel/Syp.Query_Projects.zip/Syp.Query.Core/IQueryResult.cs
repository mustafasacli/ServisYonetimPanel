﻿namespace Syp.Query.Core
{
    public interface IQueryResult
    { }
}